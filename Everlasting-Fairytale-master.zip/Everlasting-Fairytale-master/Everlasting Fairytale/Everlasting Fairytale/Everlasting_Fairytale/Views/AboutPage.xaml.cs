﻿
using Xamarin.Forms;

namespace Everlasting_Fairytale.Views
{
	public partial class AboutPage : ContentPage
	{
		public AboutPage()
		{
			InitializeComponent();
		}
	}
}
