﻿
using Xamarin.Forms;

namespace Everlasting_Fairytale.Views
{
	public partial class LoginPage : ContentPage
	{
		public LoginPage()
		{
			InitializeComponent();
		}
	}
}
